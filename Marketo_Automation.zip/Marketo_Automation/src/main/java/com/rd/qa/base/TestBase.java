package com.rd.qa.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.rd.qa.config.Driver_script;
import com.rd.qa.config.ExtentReporterNG;


public class TestBase {

	public static String browserName;
	public static Properties prop;
	public static WebDriver driver;
	
	public static Properties getPropertiesValue() throws IOException
	{
			FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + com.rd.qa.utilities.Constants.prop_path);
			prop = new Properties();
			prop.load(fis);
			return prop;	
	}
	
	public static WebDriver initialization() throws Exception
	{
		driver = Driver_script.initialize_driver();
		return driver;
	}
	
	
	
	public String getScreenShotPath(String testCaseName, WebDriver driver) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String dfile = ExtentReporterNG.createFileWithDir();
		String destFile = dfile + testCaseName+".png";
		FileUtils.copyFile(source, new File(destFile));
		return destFile;
		
	}
}
