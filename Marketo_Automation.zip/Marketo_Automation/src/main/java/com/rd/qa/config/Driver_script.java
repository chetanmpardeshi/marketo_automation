package com.rd.qa.config;

import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.rd.qa.base.TestBase;
import com.sun.tools.sjavac.Log;

import org.apache.logging.log4j.*;

public class Driver_script {

	public static Properties prop;
	public static WebDriver driver;
	public static String browserName;
	
	private static Logger Log = LogManager.getLogger(Driver_script.class.getName());
	
	public static WebDriver initialize_driver() throws Exception
	{
		
		prop = TestBase.getPropertiesValue();
		browserName = prop.getProperty("browser");
		Log.info(prop.getProperty("browser") + " Browser read from Property file");
		
		if(browserName.equalsIgnoreCase("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", prop.getProperty("chrome_driver_path"));
			driver = new ChromeDriver();
			Log.info("Received driver path from user's machines : " + prop.getProperty("chrome_driver_path"));
			Log.info("Chrome Broser is Initialized");
		}
		else if(browserName.equalsIgnoreCase("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", prop.getProperty("firefox_driver_path"));
			driver = new FirefoxDriver();
			Log.info("Received driver path from user's machines : " + prop.getProperty("firefox_driver_path"));
			Log.info("Mozilla Firefox Browser is Initialized");
		}
		else if(browserName.equalsIgnoreCase("ie"))
		{
			System.setProperty("webdriver.ie.driver", prop.getProperty("ie_driver_path"));
			driver = new InternetExplorerDriver();
		}
		else if(browserName.equalsIgnoreCase("safari"))
		{
			System.setProperty("webdriver.safari.driver", prop.getProperty("safari_driver_path"));
			driver = new SafariDriver();
		}
		else if(browserName.equalsIgnoreCase("opera"))
		{
			System.setProperty("webdriver.opera.driver", prop.getProperty("opera_driver_path"));
			driver = new OperaDriver();
		}
		else if(browserName.equalsIgnoreCase("edge"))
		{
			System.setProperty("webdriver.gecko.driver", prop.getProperty("edge_driver_path"));
			driver = new EdgeDriver();
		}
		else
		{
			Log.error("Browser is not correct");
			throw new Exception("Browser is not correct");
			
		}
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		Log.info("Implicit Wait 20 Seconds is applied to driver");
		driver.manage().window().maximize();
		//driver.get(prop.getProperty("url"));
		Log.info("Navigated to Login Page : " + prop.getProperty("url"));
		return driver;
	}
}
