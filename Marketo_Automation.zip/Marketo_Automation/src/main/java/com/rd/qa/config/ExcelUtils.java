package com.rd.qa.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {

	private static XSSFWorkbook workbook;
	private static XSSFSheet sheet;
	private static XSSFCell cell;
	
	
	public void setExcelFile(String excelFilePath, String sheetName) throws IOException
	{
		File file = new File(excelFilePath);
		FileInputStream fis = new FileInputStream(file);
		
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheet(sheetName);
		
	}
	
	public String getCellData(int rowNumber, int cellNumber)
	{
		DataFormatter formatter = new DataFormatter();
		String val = formatter.formatCellValue(sheet.getRow(rowNumber).getCell(cellNumber));
	//	cell = sheet.getRow(rowNumber).getCell(cellNumber);
		//return cell.getStringCellValue();
		return val;
	}
	
	public void setCellValue(int rowNum, int cellNum, String cellValue, String excelFilePath) throws IOException
	{
		sheet.getRow(rowNum).createCell(cellNum).setCellValue(cellValue);
		
		FileOutputStream fos = new FileOutputStream(excelFilePath);
		workbook.write(fos);
		
	}
	
	public int getRowCountInSheet()
	{
		int rowcount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		return rowcount;
	}
	
	

}
