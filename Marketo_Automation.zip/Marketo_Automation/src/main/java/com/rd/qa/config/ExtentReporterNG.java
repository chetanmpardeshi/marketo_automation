package com.rd.qa.config;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Properties;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.rd.qa.base.TestBase;

public class ExtentReporterNG {
	
	static ExtentReports extent;
	static String directory;
	static Properties prop;
	
	public static String createFileWithDir() throws IOException {	
		
		prop = TestBase.getPropertiesValue();
		prop.getProperty("Extent_Reports_Path");
		
		if(directory==null)
		{		
		String dirName = new Date().toString().replace(":", "_").replace(" ", "_");
		directory = prop.getProperty("Extent_Reports_Path") + dirName + File.separatorChar;
		  
		File dir = new File(directory);
	    if (!dir.exists()) dir.mkdirs();
		}
        return directory;
    }
	
	
	
	public static ExtentReports getReportObject()
	{
		try {
			createFileWithDir();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String path = directory +"index.html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(path);
		reporter.config().setReportName("Marketo Test Automation");
		reporter.config().setDocumentTitle("Request Demo");
		
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("QA", prop.getProperty("QA_Name"));
		extent.setSystemInfo("Test URL", prop.getProperty("url"));
		extent.setSystemInfo("Browser", prop.getProperty("browser"));
		extent.setSystemInfo("Platform", prop.getProperty("platform"));
		extent.setSystemInfo("Purpose of Testing", prop.getProperty("reason_to_test"));
		return extent;
	}

}
