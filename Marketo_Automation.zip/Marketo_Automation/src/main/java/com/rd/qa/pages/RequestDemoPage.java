package com.rd.qa.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RequestDemoPage {
	
	public WebDriver driver;
	
	@FindBy(id="FirstName")
	WebElement firstname;
	
	@FindBy(id="LastName")
	WebElement lastname;
	
	@FindBy(id="Company")
	WebElement organizationname;
	
	@FindBy(id="Email")
	WebElement email;
	
	@FindBy(id="Phone")
	WebElement phone;
	
	@FindBy(id="Organization_Type__c")
	WebElement orgtype;
	
	@FindBy(id="howDidYouHearAboutPhreesia")
	WebElement hearaboutphreesia;
	
	@FindBy(id="how_did_you_hear_about_phreesia_c")
	WebElement hearaboutphreesia_c;
	
	@FindBy(xpath="//input[@type='checkbox']")
	WebElement subscribedtoblog;
	
	@FindBy(id="demoFormContainer")
	WebElement demoFormContainer;
	

	@FindBy(xpath="//input[@type='submit']")
	WebElement submitbtn;
	
	
	public RequestDemoPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getDemoFormContainer()
	{
		firstname.isDisplayed();
		return firstname;
	}
	
	public WebElement EnterFirstName()
	{
		return firstname;
	}
	public WebElement EnterLastName()
	{
		return lastname;
	}
	public WebElement EnterEmailId()
	{
		return email;
	}
	public WebElement EnterPhoneNumber()
	{
		return phone;
	}
	public WebElement EnterOrganizationName()
	{
		return organizationname;
	}
	public WebElement SelectHereAboutPhreesia()
	{
		return hearaboutphreesia;
	}
	public WebElement SelectHereAboutPhreesia_C()
	{
		return hearaboutphreesia_c;
	}
	public WebElement SelectOrganizationType()
	{
		return orgtype;
	}
	
	public void NewsUncheck()
	{
		subscribedtoblog.click();
	}
	
	public void SubmitForm()
	{
		submitbtn.click();
	}
	
}
