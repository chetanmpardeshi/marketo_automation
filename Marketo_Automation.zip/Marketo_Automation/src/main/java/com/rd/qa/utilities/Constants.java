package com.rd.qa.utilities;

public class Constants {
	
	public static final String prop_path = "\\src\\main\\java\\com\\rd\\qa\\config\\config.properties";

}
