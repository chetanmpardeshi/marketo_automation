package com.rd.qa.testcases;

import org.testng.annotations.Test;

import com.rd.qa.base.TestBase;
import com.rd.qa.config.ExcelUtils;
import com.rd.qa.pages.RequestDemoPage;

import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.util.Properties;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class RequestDemoTest extends TestBase {
	
	public WebDriver driver;
	RequestDemoPage ObjRequestDemoPage;
	Properties prop;
	ExcelUtils excelUtils;
	String actual;
	String expected;
	String excelFilePath;
	
	String firstname, lastname, phonenumber, orgname, orgtype, orgtype_c, hereabtphreesia, hereabtphreesia_c;
	

	private static Logger Log = LogManager.getLogger(RequestDemoTest.class.getName());
	
  @BeforeClass
  public void setUp() throws Exception{
	  		driver = initialization();
	  		prop = getPropertiesValue();
	  		
	  		ObjRequestDemoPage = new RequestDemoPage(driver);	
	  		
			excelUtils = new ExcelUtils();
			excelFilePath = prop.getProperty("Test_Data_Path") + prop.getProperty("Test_Data_Excel_File");
			String excelSheetName = prop.getProperty("Excel_Sheet_Name_Provider");
			excelUtils.setExcelFile(excelFilePath, excelSheetName);
			
			firstname = prop.getProperty("firstname");
			lastname = prop.getProperty("lastname");
			phonenumber = prop.getProperty("phonenumber");
			orgname = prop.getProperty("orgname");
			orgtype = prop.getProperty("orgtype");
			orgtype_c = prop.getProperty("orgtype_c");
			hereabtphreesia = prop.getProperty("hereabtphreesia");
			hereabtphreesia_c = prop.getProperty("hereabtphreesia_c");
			
		}
 
  @Test(priority=0)
  public void VerifyPhreesiaRequestDemoForm() throws InterruptedException, IOException
  {
	  String url = excelUtils.getCellData(1,0);
	  String emailId = excelUtils.getCellData(1,1);
	  
	  driver.get(url);
	  Thread.sleep(2000);
	  
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	  js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("FirstName")));
	  
	  ObjRequestDemoPage.EnterFirstName().sendKeys(firstname);
	  Thread.sleep(1000);
	  ObjRequestDemoPage.EnterLastName().sendKeys(lastname);
	  Thread.sleep(1000);
	  ObjRequestDemoPage.EnterEmailId().sendKeys(emailId);
	  Thread.sleep(1000);
	  ObjRequestDemoPage.EnterPhoneNumber().sendKeys(phonenumber);
	  Thread.sleep(1000);
	  ObjRequestDemoPage.EnterOrganizationName().sendKeys(orgname);
	  Thread.sleep(1000);
	  WebElement selOrgType = ObjRequestDemoPage.SelectOrganizationType();
	  Select dropdownOrgType = new Select(selOrgType);
	  dropdownOrgType.selectByVisibleText(orgtype);
	  
	  Thread.sleep(1000);
	  WebElement selHereAbtPhreesia = ObjRequestDemoPage.SelectHereAboutPhreesia();
	  Select dropdownselHereAbtPhreesia = new Select(selHereAbtPhreesia);
	  dropdownselHereAbtPhreesia.selectByVisibleText(hereabtphreesia);
	  
	  ObjRequestDemoPage.NewsUncheck();
	  Thread.sleep(1000);
	//  ObjRequestDemoPage.SubmitForm();
	  Thread.sleep(1000);
	  
	  excelUtils.setCellValue(1,2,"Yesss",excelFilePath);

  }
  
  
  @Test(enabled = false)
  public void VerifyDemoRequestForms() throws InterruptedException, IOException
  {
	  
	  for(int i=0; i<=excelUtils.getRowCountInSheet(); i++)
      {
		  String url = excelUtils.getCellData(i,0);
		  driver.get(url);
		  
		  Thread.sleep(2000);
		  
		  JavascriptExecutor js = (JavascriptExecutor)driver;

		  WebElement demoFormContainer = ObjRequestDemoPage.getDemoFormContainer();
		  
		  js.executeScript("arguments[0].scrollIntoView();", demoFormContainer);
		  
		  Thread.sleep(2000);
		  
		  ObjRequestDemoPage.EnterFirstName().sendKeys("ChetanTest");
		  Thread.sleep(1000);
		  ObjRequestDemoPage.EnterLastName().sendKeys("PhreesiaTest");
		  Thread.sleep(1000);
		  
		  String emailId = excelUtils.getCellData(i,1);
		  ObjRequestDemoPage.EnterEmailId().sendKeys(emailId);
		  Thread.sleep(1000);
		  ObjRequestDemoPage.EnterPhoneNumber().sendKeys("9096116641");
		  Thread.sleep(1000);
		  ObjRequestDemoPage.EnterOrganizationName().sendKeys("Rayden");
		  Thread.sleep(1000);

		  WebElement selOrgType = ObjRequestDemoPage.SelectOrganizationType();
		  Select dropdownOrgType = new Select(selOrgType);
		  dropdownOrgType.selectByIndex(1);
		  
		  Thread.sleep(1000);
		  WebElement selHereAbtPhreesia = ObjRequestDemoPage.SelectHereAboutPhreesia();
		  Select dropdownselHereAbtPhreesia = new Select(selHereAbtPhreesia);
		  dropdownselHereAbtPhreesia.selectByIndex(2);
		  
		  Thread.sleep(1000);
		  WebElement selHereAbtPhreesia_c = ObjRequestDemoPage.SelectHereAboutPhreesia_C();
		  Select dropdownselHereAbtPhreesia_c = new Select(selHereAbtPhreesia);
		  dropdownselHereAbtPhreesia_c.selectByIndex(2);
		  
		  Thread.sleep(2000);
		  
		 // excelUtils.setCellValue(i, 2, "Yes", excelFilePath);
      }
	  
	  
  }
  
 

}
